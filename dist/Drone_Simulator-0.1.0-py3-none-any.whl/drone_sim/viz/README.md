# VIZ
This folder contains all the code required for visualising the drone plot