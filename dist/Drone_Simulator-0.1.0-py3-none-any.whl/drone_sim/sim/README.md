# SIM
This folder contains python files for running the main math behind the simulation